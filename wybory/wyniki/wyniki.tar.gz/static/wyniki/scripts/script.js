/**
 * Created by adamek on 4/3/16.
 */

function expandNavBar() {
    document.getElementsByClassName("nav-bar")[0].classList.toggle("expanded");
}